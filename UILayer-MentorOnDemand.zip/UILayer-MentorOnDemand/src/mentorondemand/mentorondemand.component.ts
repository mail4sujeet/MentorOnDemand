import { Component, OnInit, ElementRef } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './mentorondemand.component.html',
  styleUrls: ['./mentorondemand.component.css']
})
export class MentorOnDemandComponent implements OnInit {

  ngOnInit(){}
  // handleChangeInPlayer = (data:any) =>{
  //   console.log(data);
  // }
}
