import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './main-container.component.html',
  styleUrls: ['./main-container.component.css']
})
export class MainContainerComponent implements OnInit {

  ngOnInit() {}

}
