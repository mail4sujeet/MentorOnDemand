package org.mentorOnDemand.zuul.eureka.customer.shared.server.server.rest;

import java.util.List;

import org.mentorOnDemand.zuul.eureka.customer.shared.server.server.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.mentorOnDemand.zuul.eureka.customer.shared.server.server.domain.User;

@RestController
public class UserController {
	@Autowired
	private UserService userService;
	
	@RequestMapping("user/create")
	public String create(@RequestParam String firstName, @RequestParam String lastName, @RequestParam String userType, @RequestParam String userName, @RequestParam String password, @RequestParam String status){
		String userId= "USER"+Math.random();
		User user = userService.create(userId, firstName, lastName, userType, userName, password, status);
		return user.toString();
	}
	
	@RequestMapping("user/get")
	public User getPerson(@RequestParam String userId){
		return userService.getById(userId);
	}
	
	@RequestMapping("user/getAll")
	public List<User> getAll(){
		return userService.getAll();
	}

	@RequestMapping("user/update")
	public String update(@RequestParam String userId,@RequestParam String firstName, @RequestParam String lastName, @RequestParam String userType, @RequestParam String userName, @RequestParam String password, @RequestParam String status){
		User user = userService.update(userId, firstName, lastName, userType, userName, password, status);
		return user.toString();
	}
	
	@RequestMapping("user/delete")
	public String delete(@RequestParam String userId){
		userService.delete(userId);
		return "deleted " +userId;
	}
}
