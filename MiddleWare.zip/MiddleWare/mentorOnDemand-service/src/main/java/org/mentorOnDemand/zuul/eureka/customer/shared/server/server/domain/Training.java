package org.mentorOnDemand.zuul.eureka.customer.shared.server.server.domain;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Training {
	
	String title;
	String startDate;
	String endDate;
	String timings;
	
	public Training(String title, String startDate, String endDate, String timings){
		this.title= title;
		this.startDate= startDate;
		this.endDate= endDate;
		this.timings= timings;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	public String getTimings() {
		return timings;
	}
	public void setTimings(String timings) {
		this.timings = timings;
	}
	public String toString(){
		return "titile"+title+"start Date"+startDate+"end Date"+endDate;
	}

}
