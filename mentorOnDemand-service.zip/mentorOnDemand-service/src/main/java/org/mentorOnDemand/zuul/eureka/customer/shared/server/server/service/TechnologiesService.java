package org.mentorOnDemand.zuul.eureka.customer.shared.server.server.service;
import java.util.List;

import org.mentorOnDemand.zuul.eureka.customer.shared.server.server.repository.TechnologiesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.mentorOnDemand.zuul.eureka.customer.shared.server.server.domain.Technologies;

@Service
public class TechnologiesService {
	@Autowired
	private TechnologiesRepository techRepository;
	
	//create operation
	public Technologies create(String name, String mentorId, String mentorName){
		return techRepository.save(new Technologies(name, mentorId, mentorName));
	}

	//get operation
	public List<Technologies> getAll(){
		return techRepository.findAll();
	}
	
	public Technologies getByName(String name){
		return (Technologies) techRepository.findByName(name);
	}
	
	//delete operation		
	public void delete(String name){
		Technologies training = (Technologies)techRepository.findByName(name);
		techRepository.delete(training);
	}

}
