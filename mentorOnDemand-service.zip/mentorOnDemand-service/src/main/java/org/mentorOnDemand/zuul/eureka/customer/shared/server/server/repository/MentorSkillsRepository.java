package org.mentorOnDemand.zuul.eureka.customer.shared.server.server.repository;
import java.util.List;


import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import org.mentorOnDemand.zuul.eureka.customer.shared.server.server.domain.MentorSkills;

@Repository
public interface MentorSkillsRepository extends MongoRepository<MentorSkills, String>{
	public MentorSkills findByMentorName(String mentorName);
	public List<MentorSkills> findByTechnologySpecialist(String technologySpecialist);

}
