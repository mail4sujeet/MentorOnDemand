package org.mentorOnDemand.zuul.eureka.customer.shared.server.server.rest;

import java.util.List;

import org.mentorOnDemand.zuul.eureka.customer.shared.server.server.service.TrainingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.mentorOnDemand.zuul.eureka.customer.shared.server.server.domain.Training;

@RestController
public class TrainingController {
	@Autowired
	private TrainingService trainingService;
	
	@RequestMapping("training/create")
	public String create(@RequestParam String title, @RequestParam String startDate, @RequestParam String endDate, @RequestParam String timings){
		Training training = trainingService.create(title, startDate, endDate, timings);
		return training.toString();
	}
	
	@RequestMapping("training/get")
	public Training getPerson(@RequestParam String title){
		return trainingService.getByTitle(title);
	}
	
	@RequestMapping("training/getAll")
	public List<Training> getAll(){
		return trainingService.getAll();
	}
	
	@RequestMapping("training/delete")
	public String delete(@RequestParam String title){
		trainingService.delete(title);
		return "deleted " +title;
	}
}
