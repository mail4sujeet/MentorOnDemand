package org.mentorOnDemand.zuul.eureka.customer.shared.server.server.repository;

import java.util.List;


import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import org.mentorOnDemand.zuul.eureka.customer.shared.server.server.domain.Technologies;

@Repository
public interface TechnologiesRepository extends MongoRepository<Technologies, String>{
	public List<Technologies> findByName(String name);

}
