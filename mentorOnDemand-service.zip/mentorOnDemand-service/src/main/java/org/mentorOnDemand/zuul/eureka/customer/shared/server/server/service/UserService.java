package org.mentorOnDemand.zuul.eureka.customer.shared.server.server.service;

import java.util.List;

import org.mentorOnDemand.zuul.eureka.customer.shared.server.server.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.mentorOnDemand.zuul.eureka.customer.shared.server.server.domain.User;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	//create operation
	public User create(String userId, String firstName, String lastName, String userType, String userName, String password, String status){
		return userRepository.save(new User(userId, firstName, lastName, userType, userName, password, status));
	}

	//get operation
	public List<User> getAll(){
		return userRepository.findAll();
	}
	
	public User getById(String id){
		return userRepository.findByUserId(id);
	}
	
	//update operation
	public User update(String userId, String firstName, String lastName, String userType, String userName, String password, String status){
		User user = userRepository.findByUserId(userId);
		user.setId(userId);
		user.setFirstName(firstName);
		user.setLastName(lastName);
		user.setUserType(userType);
		user.setUserName(userName);
		user.setPassword(password);
		user.setStatus(status);
		return userRepository.save(user);
	}
	
	//delete operation		
	public void delete(String id){
		User user = userRepository.findByUserId(id);
		userRepository.delete(user);
	}
}
