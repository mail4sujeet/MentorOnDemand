package org.mentorOnDemand.zuul.eureka.customer.shared.server.server.domain;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Technologies {
	String name;
	String mentorId;
	String mentorName;
	
	public Technologies(String name, String mentorId, String mentorName){
		this.name= name;
		this.mentorId= mentorId;
		this.mentorName= mentorName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMentorId() {
		return mentorId;
	}
	public void setMentorId(String mentorId) {
		this.mentorId = mentorId;
	}
	public String getMentorName() {
		return mentorName;
	}
	public void setMentorName(String mentorName) {
		this.mentorName = mentorName;
	}
	public String toString(){
		return "name"+name+"mentor id"+mentorId+"mentor name"+mentorName;
	}
}
