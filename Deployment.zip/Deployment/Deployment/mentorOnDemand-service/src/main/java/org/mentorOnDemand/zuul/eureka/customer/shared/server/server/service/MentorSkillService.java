package org.mentorOnDemand.zuul.eureka.customer.shared.server.server.service;
import java.util.List;

import org.mentorOnDemand.zuul.eureka.customer.shared.server.server.repository.MentorSkillsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.mentorOnDemand.zuul.eureka.customer.shared.server.server.domain.MentorSkills;

@Service
public class MentorSkillService {

	@Autowired
	private MentorSkillsRepository mentorRepository;
	
	//create operation
	public MentorSkills create(String mentorName, int experience, int NoOfTraining, String technologySpecialist, Double feeCharge, String rating){
		return mentorRepository.save(new MentorSkills(mentorName, experience, NoOfTraining, technologySpecialist, feeCharge, rating));
	}

	//get operation
	public List<MentorSkills> getAll(){
		return mentorRepository.findAll();
	}
	
	public MentorSkills getByName(String mentorName){
		return mentorRepository.findByMentorName(mentorName);
	}
		
	//delete operation		
	public void delete(String mentorName){
		MentorSkills mentor = mentorRepository.findByMentorName(mentorName);
		mentorRepository.delete(mentor);
	}
}
