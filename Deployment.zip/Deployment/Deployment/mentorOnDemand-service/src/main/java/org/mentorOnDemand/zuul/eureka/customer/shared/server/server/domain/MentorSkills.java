package org.mentorOnDemand.zuul.eureka.customer.shared.server.server.domain;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class MentorSkills {

	String mentorName;
	int experience;
	int NoOfTraining;
	String technologySpecialist;
	double feeCharge;
	String rating;
	
	public MentorSkills(String mentorName, int experience, int NoOfTraining, String technologySpecialist, double feeCharge, String rating){
		this.mentorName= mentorName;
		this.experience= experience;
		this.NoOfTraining= NoOfTraining;
		this.technologySpecialist= technologySpecialist;
		this.feeCharge= feeCharge;
		this.rating= rating;
	}
	
	public String getMentorName() {
		return mentorName;
	}

	public void setMentorName(String mentorName) {
		this.mentorName = mentorName;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public int getNoOfTraining() {
		return NoOfTraining;
	}

	public void setNoOfTraining(int noOfTraining) {
		NoOfTraining = noOfTraining;
	}

	public String getTechnologySpecialist() {
		return technologySpecialist;
	}

	public void setTechnologySpecialist(String technologySpecialist) {
		this.technologySpecialist = technologySpecialist;
	}

	public double getFeeCharge() {
		return feeCharge;
	}

	public void setFeeCharge(Double feeCharge) {
		this.feeCharge = feeCharge;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public String toString(){
		return "Mentor name"+mentorName+"Experience"+experience +"Number of Training Delivered"+NoOfTraining+"Technology Specialist"+technologySpecialist+"Mentor Fee Charging"+feeCharge+"Mentor rating"+rating;
	}

}
