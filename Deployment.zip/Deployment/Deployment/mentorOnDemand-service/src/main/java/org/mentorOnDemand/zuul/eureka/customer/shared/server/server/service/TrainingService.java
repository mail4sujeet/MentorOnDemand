package org.mentorOnDemand.zuul.eureka.customer.shared.server.server.service;
import java.util.List;

import org.mentorOnDemand.zuul.eureka.customer.shared.server.server.repository.TrainingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.mentorOnDemand.zuul.eureka.customer.shared.server.server.domain.Training;

@Service
public class TrainingService {
	
	@Autowired
	private TrainingRepository trainingRepository;
	
	//create operation
	public Training create(String title, String startDate, String endDate, String timings){
		return trainingRepository.save(new Training(title, startDate, endDate, timings));
	}

	//get operation
	public List<Training> getAll(){
		return trainingRepository.findAll();
	}
	
	public Training getByTitle(String title){
		return (Training) trainingRepository.findByTitle(title);
	}
	
	//delete operation		
	public void delete(String title){
		Training training = (Training)trainingRepository.findByTitle(title);
		trainingRepository.delete(training);
	}

}
