package org.mentorOnDemand.zuul.eureka.customer.shared.server.server.domain;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class User {
	
	String userId;
	String firstName;
	String lastName;
	String userType;
	String userName;
	String password;	
	String status;	
	
	public User(String userId, String firstName, String lastName, String userType, String userName, String password, String status){
		this.userId= userId;
		this.firstName= firstName;
		this.lastName= lastName;
		this.userType= userType;
		this.userName= userName;
		this.password= password;
		this.status= status;
	}

	public String getId() {
		return userId;
	}

	public void setId(String userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String toString(){
		return "User Id"+userId+"User first Name"+firstName +"User last name"+lastName+"User type"+userType+"User Name"+userName+"User password"+password+"User Status"+status;
	}

}
