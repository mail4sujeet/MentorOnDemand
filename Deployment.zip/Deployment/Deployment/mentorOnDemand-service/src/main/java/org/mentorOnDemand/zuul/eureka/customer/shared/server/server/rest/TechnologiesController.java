package org.mentorOnDemand.zuul.eureka.customer.shared.server.server.rest;
import java.util.List;

import org.mentorOnDemand.zuul.eureka.customer.shared.server.server.service.TechnologiesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.mentorOnDemand.zuul.eureka.customer.shared.server.server.domain.Technologies;

@RestController
public class TechnologiesController {
	@Autowired
	private TechnologiesService techService;
	
	@RequestMapping("technologies/create")
	public String create(@RequestParam String name, @RequestParam String mentorId, @RequestParam String mentorName){
		Technologies tech = techService.create(name, mentorId, mentorName);
		return tech.toString();
	}
	
	@RequestMapping("technologies/get")
	public Technologies getPerson(@RequestParam String name){
		return techService.getByName(name);
	}
	
	@RequestMapping("technologies/getAll")
	public List<Technologies> getAll(){
		return techService.getAll();
	}
	
	@RequestMapping("technologies/delete")
	public String delete(@RequestParam String name){
		techService.delete(name);
		return "deleted " +name;
	}

}
