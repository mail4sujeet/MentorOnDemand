package org.mentorOnDemand.zuul.eureka.customer.shared.server.server.rest;
import java.util.List;

import org.mentorOnDemand.zuul.eureka.customer.shared.server.server.service.MentorSkillService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.mentorOnDemand.zuul.eureka.customer.shared.server.server.domain.MentorSkills;

@RestController

public class MentorSkillsController {
	@Autowired
	private MentorSkillService mentorService;
	
	@RequestMapping("mentor/create")
	public String create(@RequestParam String mentorName, @RequestParam int experience, @RequestParam int NoOfTraining, @RequestParam String technologySpecialist, @RequestParam double feeCharge, @RequestParam String rating){
		MentorSkills mentor = mentorService.create(mentorName, experience, NoOfTraining, technologySpecialist, feeCharge, rating);
		return mentor.toString();
	}
	
	@RequestMapping("mentor/get")
	public MentorSkills getPerson(@RequestParam String mentorName){
		return mentorService.getByName(mentorName);
	}
	
	@RequestMapping("mentor/getAll")
	public List<MentorSkills> getAll(){
		return mentorService.getAll();
	}
	
	@RequestMapping("mentor/delete")
	public String delete(@RequestParam String userId){
		mentorService.delete(userId);
		return "deleted " +userId;
	}
}
